import keyboard

# 1️⃣ 監聽單鍵按下
def 監聽按下(key: str, func):
    """
    監聽單一按鍵「按下」事件。

    參數:
        key (str): 要監聽的按鍵名稱，例如 'a' 或 'space'
        func: 按下後要執行的 function/method/lambda

    說明:
        func(callback) 的第一個參數會是 event，但你可使用 lambda _: 省略。

    範例:
        監聽按下("a", lambda _: print("按下 A"))
    """
    keyboard.on_press_key(key, func)


# 2️⃣ 監聽單鍵放開
def 監聽放開(key: str, func):
    """
    監聽單一按鍵「放開」事件。

    參數:
        key (str): 按鍵名
        func: 放開後要執行的 function/method/lambda

    範例:
        監聽放開("a", lambda _: print("放開 A"))
    """
    keyboard.on_release_key(key, func)


# 3️⃣ 監聽任意鍵按下
def 監聽任意鍵(func):
    """
    監聽所有按鍵的按下事件。

    參數:
        func: callback(event)
            event.name = 被按下的按鍵名稱

    範例:
        監聽任意鍵(lambda e: print(e.name))
    """
    keyboard.on_press(func)


# 4️⃣ 監聽熱鍵（如 ctrl+alt+a）
def 監聽熱鍵(組合鍵: str, func):
    """
    設定熱鍵（hotkey listener），按下組合鍵時執行 func。

    參數:
        組合鍵 (str): 例如 'ctrl+shift+a'
        func: 熱鍵觸發時執行的動作

    回傳:
        int: hotkey ID，可用於取消監聽

    範例:
        監聽熱鍵("ctrl+shift+a", lambda: print("觸發"))
    """
    return keyboard.add_hotkey(組合鍵, func)


# 5️⃣ 監聽組合鍵（同 add_hotkey）
def 監聽組合鍵(組合鍵: str, func):
    """
    與熱鍵相同，用於監聽多鍵組合，例如 shift + a。

    參數:
        組合鍵 (str)
        func: 執行動作

    回傳:
        int: hook ID
    """
    return keyboard.add_hotkey(組合鍵, func)


# 6️⃣ 設定快捷鍵（單鍵或組合鍵）
def 設定快捷鍵(按鍵: str, func):
    """
    設定快捷鍵，按下特定按鍵會執行 function。

    參數:
        按鍵 (str): 支援 a、b、space、ctrl+q 等
        func: 要執行的動作

    回傳:
        int: hotkey ID
    """
    return keyboard.add_hotkey(按鍵, func)


# 7️⃣ 阻擋按鍵（讓按鍵無效）
def 阻擋按鍵(按鍵: str):
    """
    阻擋某按鍵，使其在系統中完全失效。

    參數:
        按鍵 (str): 要封鎖的按鍵

    範例:
        阻擋按鍵("a") → A 完全不能按
    """
    keyboard.block_key(按鍵)


# 8️⃣ 模擬按下按鍵
def 模擬按下(按鍵: str):
    """
    模擬按下某個按鍵（不會自動放開）。

    參數:
        按鍵 (str)

    範例:
        模擬按下("a")
    """
    keyboard.press(按鍵)


# 9️⃣ 模擬放開按鍵
def 模擬放開(按鍵: str):
    """
    模擬放開某按鍵。

    參數:
        按鍵 (str)
    """
    keyboard.release(按鍵)


# 🔟 模擬單次按鍵（按下 + 放開）
def 模擬點擊(按鍵: str):
    """
    模擬一次完整按鍵（press + release）。

    參數:
        按鍵 (str)
    """
    keyboard.send(按鍵)


# 1️⃣1️⃣ 檢查按鍵是否正在被按住
def 是否按住(按鍵: str) -> bool:
    """
    回傳某按鍵目前是否被按住。

    參數:
        按鍵 (str)

    回傳:
        bool: True 表示有按住

    範例:
        if 是否按住("a"):
            print("A 正在被按住")
    """
    return keyboard.is_pressed(按鍵)


# 1️⃣2️⃣ 長按觸發（按住期間重複觸發）
def 長按觸發(按鍵: str, func):
    """
    當按鍵被按住時，會持續觸發 func。

    參數:
        按鍵 (str)
        func: 要重複呼叫的 function

    原理:
        每次按下時檢查是否仍按住，若有就呼叫 func()
    """
    def wrapper():
        if keyboard.is_pressed(按鍵):
            func()
    keyboard.on_press_key(按鍵, lambda _: wrapper())


# 1️⃣3️⃣ 取消某監聽
def 取消監聽(hook_id: int):
    """
    取消特定 hotkey/監聽。

    參數:
        hook_id (int): add_hotkey 回傳的 ID
    """
    keyboard.remove_hotkey(hook_id)


# 1️⃣4️⃣ 停止所有監聽
def 全部停止監聽():
    """
    移除所有 keyboard 的監聽事件。
    """
    keyboard.unhook_all()


# 1️⃣5️⃣ 錄製鍵盤事件（Macro recorder）

