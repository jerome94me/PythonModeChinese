# 為什麼我要做這個東西？
就是最近python不是很流行嗎?

很多人就去學python

但是我發現有些頻道不會教全部的東西

例如:"Papaya電腦教室"

雖然一個影片只有10~20分鐘

但是教的內容有沒那麼多

但那些很長的影片初學者不會有耐心去看

所以我打算做一個中文模組

## 讓所有初學者都可以開發屬於自己的軟體！
雖然我不算太會寫python

但我是會寫tkinter的(但我不會寫pygame)

功能不一定有全部

但夠用了
--- 
# 此專案：
- 方法：Vibe Coding, normal Coding
- 代碼：Jerome

- 程式語言：Python, Markdown

- 用的模組：Python, Bookmarks, Vscode繁體中文補丁, Gitlens, indent-rainbow